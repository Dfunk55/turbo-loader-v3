#!/usr/bin/env python3
"""
Turbo Loader v3 - Installation Test Script
Basic testing functionality for development builds
"""

import sys
import json
from pathlib import Path

def test_basic_installation():
    """Test basic installation requirements"""
    print("Testing Turbo Loader v3 installation...")
    
    # Find plugin directory
    plugin_dir = Path.home() / "Documents" / "Dungeondraft Mods" / "TurboLoaderV3"
    
    if not plugin_dir.exists():
        print("❌ Plugin directory not found")
        return False
    
    # Check required files
    required_files = ["TurboLoaderV3.ddmod", "main.gd", "config.json"]
    for file_name in required_files:
        if not (plugin_dir / file_name).exists():
            print(f"❌ Missing required file: {file_name}")
            return False
    
    print("✅ Basic installation test passed")
    return True

if __name__ == "__main__":
    success = test_basic_installation()
    sys.exit(0 if success else 1)
